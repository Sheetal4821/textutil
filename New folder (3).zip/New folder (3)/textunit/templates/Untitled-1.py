  #charcter counter


elif(charcount=='on'):
        analyzed=''
        for char in djtext:
                analyzed="Total charcters:"+str(len(djtext))
        params={'purpose':'characters are:','analyzed_text':analyzed}
        return render(request,'analyze.html',params)
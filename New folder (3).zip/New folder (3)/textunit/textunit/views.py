#i have create this
from django.http import HttpResponse
from django.shortcuts import render
#video 6 code
#def index(request):
    #return HttpResponse( '<a href="https://classroom.google.com/u/0/h" >  google classroom </a>')
#def about(request):
   # return HttpResponse('hello about')
   #video 7 code
#def index(request):
   # return HttpResponse("home")   
#def removepunc(request):
    #return HttpResponse( "removepunc")   
#def capfirst(request):
    #return HttpResponse( "capfirst") ]  
#def newlineremover(request):
    #return HttpResponse( "newlineremover <a href='/'> BACK</a>")   
#def spacerremove(request):
   # return HttpResponse( "spacerremove")   
#def charcount(request):
    #return HttpResponse( "charcount")   
#video 8 code
#def index(request):
    #params = { 'name' :'sheetal' , 'place' :'bhilwara'}
    #return render( request, 'index.html', params)
    #video 9 code
#def index(request):
   #return render( request, 'index.html')
   #get the information
#def removepunc(request):
    #djform = request.GET.get('name','default')
    #print (djform)
    #return HttpResponse( "removepunc")
#code for video 10

def index(request):
   return render( request, 'index.html')
  #checkcheck box value
def analyze(request):
    djform = request.POST.get('text','default')
    removepunc = request.POST.get('removepunc','off')
    fullcaps = request.POST.get('uppercase','off')
    newlineremover = request.POST.get('newlineremover','off')
    #print (djform)
    #print (removepunc)
#check which checkbx is on

    if removepunc =="on":
    #analyzed=djform
     punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''

     analyzed=""

     for char in djform:
       if char  not in  punctuations:
          analyzed = analyzed + char
          params = {'purpose':'Removed Punctuations', 'analyzed_text': analyzed}
          djtext = analyzed
    if(fullcaps=="on"):
        analyzed = ""
        for char in djtext:
            analyzed = analyzed + char.upper()

        params = {'purpose': 'Changed to Uppercase', 'analyzed_text': analyzed}
        djtext = analyzed
    if(newlineremover=="on"):
        analyzed=""
        for char in djform:
         if char !="/n"  and char!="\r":
           params = { 'purpose' :'newline remover' , 'analyzed_text' :analyzed}
           analyzed = analyzed + char
    else:
        
        print("no")
        print("pre", analyzed)
        params = {'purpose': 'Removed NewLines', 'analyzed_text': analyzed}

    if(removepunc != "on" and newlineremover!="on"  and fullcaps!="on"):
        return HttpResponse("please select any operation and try again")

    return render(request, 'analyze.html', params)
    
